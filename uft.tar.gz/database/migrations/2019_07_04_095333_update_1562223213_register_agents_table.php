<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1562223213RegisterAgentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('register_agents', function (Blueprint $table) {
            if(Schema::hasColumn('register_agents', 'role_id')) {
                $table->dropForeign('320336_5d1b46ae3bfd5');
                $table->dropIndex('320336_5d1b46ae3bfd5');
                $table->dropColumn('role_id');
            }
            if(Schema::hasColumn('register_agents', 'email_id')) {
                $table->dropForeign('320336_5d1b47c555596');
                $table->dropIndex('320336_5d1b47c555596');
                $table->dropColumn('email_id');
            }
            if(Schema::hasColumn('register_agents', 'password_id')) {
                $table->dropForeign('320336_5d1b47c578889');
                $table->dropIndex('320336_5d1b47c578889');
                $table->dropColumn('password_id');
            }
            if(Schema::hasColumn('register_agents', 'full_name_id')) {
                $table->dropForeign('320336_5d1b573faa3c0');
                $table->dropIndex('320336_5d1b573faa3c0');
                $table->dropColumn('full_name_id');
            }
            
        });
Schema::table('register_agents', function (Blueprint $table) {
            
if (!Schema::hasColumn('register_agents', 'email')) {
                $table->string('email')->nullable();
                }
if (!Schema::hasColumn('register_agents', 'password')) {
                $table->string('password')->nullable();
                }
if (!Schema::hasColumn('register_agents', 'full_name')) {
                $table->string('full_name')->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('register_agents', function (Blueprint $table) {
            $table->dropColumn('email');
            $table->dropColumn('password');
            $table->dropColumn('full_name');
            
        });
Schema::table('register_agents', function (Blueprint $table) {
                        
        });

    }
}
