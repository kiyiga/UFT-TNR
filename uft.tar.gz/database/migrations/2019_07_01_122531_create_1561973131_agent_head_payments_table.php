<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1561973131AgentHeadPaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('agent_head_payments')) {
            Schema::create('agent_head_payments', function (Blueprint $table) {
                $table->increments('id');
                $table->date('date')->nullable();
                $table->double('highest_erollment', 4, 2)->nullable();
                $table->double('lowest_erollment', 4, 2)->nullable();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('agent_head_payments');
    }
}
