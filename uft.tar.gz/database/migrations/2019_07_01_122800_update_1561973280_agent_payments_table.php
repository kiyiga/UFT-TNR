<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1561973280AgentPaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('agent_payments', function (Blueprint $table) {
            if(Schema::hasColumn('agent_payments', 'full_name')) {
                $table->dropColumn('full_name');
            }
            if(Schema::hasColumn('agent_payments', 'district')) {
                $table->dropColumn('district');
            }
            if(Schema::hasColumn('agent_payments', 'amount')) {
                $table->dropColumn('amount');
            }
            
        });
Schema::table('agent_payments', function (Blueprint $table) {
            
if (!Schema::hasColumn('agent_payments', 'date')) {
                $table->date('date')->nullable();
                }
if (!Schema::hasColumn('agent_payments', 'highest_erollment')) {
                $table->double('highest_erollment', 4, 2)->nullable();
                }
if (!Schema::hasColumn('agent_payments', 'lowest_erollment')) {
                $table->double('lowest_erollment', 4, 2)->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('agent_payments', function (Blueprint $table) {
            $table->dropColumn('date');
            $table->dropColumn('highest_erollment');
            $table->dropColumn('lowest_erollment');
            
        });
Schema::table('agent_payments', function (Blueprint $table) {
                        $table->string('full_name')->nullable();
                $table->string('district')->nullable();
                $table->double('amount', 4, 2)->nullable();
                
        });

    }
}
