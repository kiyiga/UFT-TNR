<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5d1b47cae6a63RelationshipsToRegisterAgentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('register_agents', function(Blueprint $table) {
            if (!Schema::hasColumn('register_agents', 'role_id')) {
                $table->integer('role_id')->unsigned()->nullable();
                $table->foreign('role_id', '320336_5d1b46ae3bfd5')->references('id')->on('roles')->onDelete('cascade');
                }
                if (!Schema::hasColumn('register_agents', 'email_id')) {
                $table->integer('email_id')->unsigned()->nullable();
                $table->foreign('email_id', '320336_5d1b47c555596')->references('id')->on('users')->onDelete('cascade');
                }
                if (!Schema::hasColumn('register_agents', 'password_id')) {
                $table->integer('password_id')->unsigned()->nullable();
                $table->foreign('password_id', '320336_5d1b47c578889')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('register_agents', function(Blueprint $table) {
            
        });
    }
}
