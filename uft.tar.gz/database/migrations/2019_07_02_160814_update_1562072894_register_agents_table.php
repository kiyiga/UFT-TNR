<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1562072894RegisterAgentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('register_agents', function (Blueprint $table) {
            if(Schema::hasColumn('register_agents', 'full_name')) {
                $table->dropColumn('full_name');
            }
            
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('register_agents', function (Blueprint $table) {
                        $table->string('full_name')->nullable();
                
        });

    }
}
