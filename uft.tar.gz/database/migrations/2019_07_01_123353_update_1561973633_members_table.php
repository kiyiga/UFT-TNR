<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1561973633MembersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('members', function (Blueprint $table) {
            if(Schema::hasColumn('members', 'recommeder')) {
                $table->dropColumn('recommeder');
            }
            if(Schema::hasColumn('members', 'dateofbirth')) {
                $table->dropColumn('dateofbirth');
            }
            if(Schema::hasColumn('members', 'district')) {
                $table->dropColumn('district');
            }
            
        });
Schema::table('members', function (Blueprint $table) {
            
if (!Schema::hasColumn('members', 'amount')) {
                $table->double('amount', 4, 2)->nullable();
                }
if (!Schema::hasColumn('members', 'date')) {
                $table->date('date')->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('members', function (Blueprint $table) {
            $table->dropColumn('amount');
            $table->dropColumn('date');
            
        });
Schema::table('members', function (Blueprint $table) {
                        $table->string('recommeder')->nullable();
                $table->date('dateofbirth')->nullable();
                $table->string('district')->nullable();
                
        });

    }
}
