<?php

$factory->define(App\Payment::class, function (Faker\Generator $faker) {
    return [

    ];
});
