<?php

$factory->define(App\AgentPayment::class, function (Faker\Generator $faker) {
    return [
        "date" => $faker->date("Y-m-d", $max = 'now'),
        "highest_erollment" => $faker->randomFloat(2, 1, 100),
        "lowest_erollment" => $faker->randomFloat(2, 1, 100),
    ];
});
