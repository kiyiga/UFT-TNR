<?php

$factory->define(App\Member::class, function (Faker\Generator $faker) {
    return [
        "full_name" => $faker->name,
        "amount" => $faker->randomFloat(2, 1, 100),
        "date" => $faker->date("Y-m-d", $max = 'now'),
    ];
});
