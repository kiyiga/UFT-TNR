<?php

$factory->define(App\RegisterAgent::class, function (Faker\Generator $faker) {
    return [
        "username" => $faker->name,
        "dateofbirth" => $faker->date("Y-m-d", $max = 'now'),
        "district" => $faker->name,
        "signature" => $faker->name,
        "gender" => collect(["&amp;amp;amp;amp;amp;#039;M&amp;amp;amp;amp;amp;#039;","&amp;amp;amp;amp;amp;#039;F&amp;amp;amp;amp;amp;#039;",])->random(),
        "email" => $faker->safeEmail,
        "password" => str_random(10),
        "full_name" => $faker->name,
        "role_id" => factory('App\Role')->create(),
    ];
});
