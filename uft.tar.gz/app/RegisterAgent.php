<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Hash;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class RegisterAgent
 *
 * @package App
 * @property string $username
 * @property string $dateofbirth
 * @property string $district
 * @property string $signature
 * @property enum $gender
 * @property string $email
 * @property string $password
 * @property string $full_name
 * @property string $role
*/
class RegisterAgent extends Model
{
    use SoftDeletes;

    protected $fillable = ['username', 'dateofbirth', 'district', 'signature', 'gender', 'email', 'password', 'full_name', 'role_id'];
    protected $hidden = ['password'];
    
    
    public static function boot()
    {
        parent::boot();

        RegisterAgent::observe(new \App\Observers\UserActionsObserver);
    }

    public static $enum_gender = ["&amp;amp;amp;amp;amp;#039;M&amp;amp;amp;amp;amp;#039;" => "&amp;amp;amp;amp;amp;#039;M&amp;amp;amp;amp;amp;#039;", "&amp;amp;amp;amp;amp;#039;F&amp;amp;amp;amp;amp;#039;" => "&amp;amp;amp;amp;amp;#039;F&amp;amp;amp;amp;amp;#039;"];

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setDateofbirthAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['dateofbirth'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['dateofbirth'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getDateofbirthAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }/**
     * Hash password
     * @param $input
     */
    public function setPasswordAttribute($input)
    {
        if ($input)
            $this->attributes['password'] = app('hash')->needsRehash($input) ? Hash::make($input) : $input;
    }
    

    /**
     * Set to null if empty
     * @param $input
     */
    public function setRoleIdAttribute($input)
    {
        $this->attributes['role_id'] = $input ? $input : null;
    }
    
    public function role()
    {
        return $this->belongsTo(Role::class, 'role_id');
    }
    
}
