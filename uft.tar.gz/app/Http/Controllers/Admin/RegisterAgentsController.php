<?php

namespace App\Http\Controllers\Admin;

use App\RegisterAgent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreRegisterAgentsRequest;
use App\Http\Requests\Admin\UpdateRegisterAgentsRequest;

class RegisterAgentsController extends Controller
{
    /**
     * Display a listing of RegisterAgent.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (! Gate::allows('register_agent_access')) {
            return abort(401);
        }


        if (request('show_deleted') == 1) {
            if (! Gate::allows('register_agent_delete')) {
                return abort(401);
            }
            $register_agents = RegisterAgent::onlyTrashed()->get();
        } else {
            $register_agents = RegisterAgent::all();
        }

        return view('admin.register_agents.index', compact('register_agents'));
    }

    /**
     * Show the form for creating new RegisterAgent.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (! Gate::allows('register_agent_create')) {
            return abort(401);
        }
        
        $roles = \App\Role::get()->pluck('title', 'id')->prepend(trans('quickadmin.qa_please_select'), '');
        $enum_gender = RegisterAgent::$enum_gender;
            
        return view('admin.register_agents.create', compact('enum_gender', 'roles'));
    }

    /**
     * Store a newly created RegisterAgent in storage.
     *
     * @param  \App\Http\Requests\StoreRegisterAgentsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreRegisterAgentsRequest $request)
    {
        if (! Gate::allows('register_agent_create')) {
            return abort(401);
        }
        $register_agent = RegisterAgent::create($request->all());



        return redirect()->route('admin.register_agents.index');
    }


    /**
     * Show the form for editing RegisterAgent.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (! Gate::allows('register_agent_edit')) {
            return abort(401);
        }
        
        $roles = \App\Role::get()->pluck('title', 'id')->prepend(trans('quickadmin.qa_please_select'), '');
        $enum_gender = RegisterAgent::$enum_gender;
            
        $register_agent = RegisterAgent::findOrFail($id);

        return view('admin.register_agents.edit', compact('register_agent', 'enum_gender', 'roles'));
    }

    /**
     * Update RegisterAgent in storage.
     *
     * @param  \App\Http\Requests\UpdateRegisterAgentsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateRegisterAgentsRequest $request, $id)
    {
        if (! Gate::allows('register_agent_edit')) {
            return abort(401);
        }
        $register_agent = RegisterAgent::findOrFail($id);
        $register_agent->update($request->all());



        return redirect()->route('admin.register_agents.index');
    }


    /**
     * Display RegisterAgent.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (! Gate::allows('register_agent_view')) {
            return abort(401);
        }
        $register_agent = RegisterAgent::findOrFail($id);

        return view('admin.register_agents.show', compact('register_agent'));
    }


    /**
     * Remove RegisterAgent from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (! Gate::allows('register_agent_delete')) {
            return abort(401);
        }
        $register_agent = RegisterAgent::findOrFail($id);
        $register_agent->delete();

        return redirect()->route('admin.register_agents.index');
    }

    /**
     * Delete all selected RegisterAgent at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if (! Gate::allows('register_agent_delete')) {
            return abort(401);
        }
        if ($request->input('ids')) {
            $entries = RegisterAgent::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore RegisterAgent from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        if (! Gate::allows('register_agent_delete')) {
            return abort(401);
        }
        $register_agent = RegisterAgent::onlyTrashed()->findOrFail($id);
        $register_agent->restore();

        return redirect()->route('admin.register_agents.index');
    }

    /**
     * Permanently delete RegisterAgent from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        if (! Gate::allows('register_agent_delete')) {
            return abort(401);
        }
        $register_agent = RegisterAgent::onlyTrashed()->findOrFail($id);
        $register_agent->forceDelete();

        return redirect()->route('admin.register_agents.index');
    }
}
