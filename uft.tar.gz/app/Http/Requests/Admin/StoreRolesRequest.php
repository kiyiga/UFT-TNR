<?php
namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreRolesRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title' => 'required',
            'register_agents.*.username' => 'required|unique:register_agents,username,'.$this->route('register_agent'),
            'register_agents.*.district' => 'required',
            'register_agents.*.signature' => 'required|unique:register_agents,signature,'.$this->route('register_agent'),
            'register_agents.*.email' => 'required|email|unique:register_agents,email',
            'register_agents.*.full_name' => 'required',
        ];
    }
}
