<?php
namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRegisterAgentsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            
            'username' => 'required|unique:register_agents,username,'.$this->route('register_agent'),
            'dateofbirth' => 'required|date_format:'.config('app.date_format'),
            'district' => 'required',
            'signature' => 'required|unique:register_agents,signature,'.$this->route('register_agent'),
            'gender' => 'required',
            'email' => 'required|email|unique:register_agents,email,'.$this->route('register_agent'),
            'full_name' => 'required',
            'role_id' => 'required',
        ];
    }
}
