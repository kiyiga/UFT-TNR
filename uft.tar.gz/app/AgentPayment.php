<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class AgentPayment
 *
 * @package App
 * @property string $date
 * @property double $highest_erollment
 * @property double $lowest_erollment
*/
class AgentPayment extends Model
{
    use SoftDeletes;

    protected $fillable = ['date', 'highest_erollment', 'lowest_erollment'];
    protected $hidden = [];
    
    
    public static function boot()
    {
        parent::boot();

        AgentPayment::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setDateAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['date'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['date'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getDateAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setHighestErollmentAttribute($input)
    {
        if ($input != '') {
            $this->attributes['highest_erollment'] = $input;
        } else {
            $this->attributes['highest_erollment'] = null;
        }
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setLowestErollmentAttribute($input)
    {
        if ($input != '') {
            $this->attributes['lowest_erollment'] = $input;
        } else {
            $this->attributes['lowest_erollment'] = null;
        }
    }
    
}
