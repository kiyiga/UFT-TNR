<?php

namespace App\Providers;

use App\Role;
use App\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        'App\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        $user = \Auth::user();

        
        // Auth gates for: User management
        Gate::define('user_management_access', function ($user) {
            return in_array($user->role_id, [1]);
        });

        // Auth gates for: Users
        Gate::define('user_access', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('user_create', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('user_edit', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('user_view', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('user_delete', function ($user) {
            return in_array($user->role_id, [1]);
        });

        // Auth gates for: User actions
        Gate::define('user_action_access', function ($user) {
            return in_array($user->role_id, [1, 2]);
        });

        // Auth gates for: Register agent
        Gate::define('register_agent_access', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('register_agent_create', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('register_agent_edit', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('register_agent_view', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('register_agent_delete', function ($user) {
            return in_array($user->role_id, [1]);
        });

        // Auth gates for: Members
        Gate::define('member_access', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('member_create', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('member_edit', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('member_view', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('member_delete', function ($user) {
            return in_array($user->role_id, [1]);
        });

        // Auth gates for: Payments
        Gate::define('payment_access', function ($user) {
            return in_array($user->role_id, [1]);
        });

        // Auth gates for: Agent payment
        Gate::define('agent_payment_access', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('agent_payment_create', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('agent_payment_edit', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('agent_payment_view', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('agent_payment_delete', function ($user) {
            return in_array($user->role_id, [1]);
        });

        // Auth gates for: Agent head payment
        Gate::define('agent_head_payment_access', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('agent_head_payment_create', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('agent_head_payment_edit', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('agent_head_payment_view', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('agent_head_payment_delete', function ($user) {
            return in_array($user->role_id, [1]);
        });

    }
}
